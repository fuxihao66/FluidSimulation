//
//  BPS3DImplicit.cpp
//  Droplet3D
//
//  Created by Fang Da on 10/3/15.
//
//

#include "BPS3D.h"
#include "SimOptions.h"

void BPS3D::step_implicit(double dt, const Partitioning & partitioning)
{
    std::cout << "Implicit time stepping" << std::endl;
    
    assert(!"Not implemented");
    
    std::cout << "Implicit time stepping finished" << std::endl;
}
