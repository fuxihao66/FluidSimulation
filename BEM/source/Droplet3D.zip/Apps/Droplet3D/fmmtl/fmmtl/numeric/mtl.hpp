
#define MTL_WITH_AUTO
#define MTL_WITH_DEFAULTIMPL
#define MTL_WITH_INITLIST
#define MTL_WITH_MOVE
#define MTL_WITH_RANGEDFOR
#define MTL_WITH_STATICASSERT
#define MTL_WITH_TEMPLATE_ALIAS
#define MTL_WITH_VARIADIC_TEMPLATE
#include <boost/numeric/mtl/mtl.hpp>

// TODO: Adaptors with fmmtl norm, etc
