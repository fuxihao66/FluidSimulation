#ifndef NEG_H
#define NEG_H

// Released into the public domain by Robert Bridson, 2009.

#ifdef __cplusplus   
extern "C" {
#endif
    
    double
    neg(double x);
    
#ifdef __cplusplus
} // end of extern "C" block
#endif

#endif
