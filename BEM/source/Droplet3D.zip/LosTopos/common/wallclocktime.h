#ifndef WALLCLOCKTIME_H
#define WALLCLOCKTIME_H

namespace LosTopos {

  void set_time_base(void);
double get_time_in_seconds(void);

}
#endif
