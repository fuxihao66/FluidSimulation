#ifndef LEVELSET_UTIL_H
#define LEVELSET_UTIL_H

float fraction_inside(float phi_left, float phi_right);
float fraction_inside(float phi_bl, float phi_br, float phi_tl, float phi_tr);

#endif